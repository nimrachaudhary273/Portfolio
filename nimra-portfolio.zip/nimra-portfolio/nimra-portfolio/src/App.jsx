import { useEffect, useRef, useState } from "react";
import "./App.css";
import photo from "./photo";
import projects from "./projects";

function useIsMobile(breakpoint = 700) {
  const [isMobile, setIsMobile] = useState(
    () => typeof window !== "undefined" && window.innerWidth <= breakpoint
  );

  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${breakpoint}px)`);
    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, [breakpoint]);

  return isMobile;
}

function ProjectSlider({ items }) {
  const isMobile = useIsMobile(700);
  const perPage = isMobile ? 1 : 2;
  const totalPages = Math.ceil(items.length / perPage);
  const [page, setPage] = useState(0);

  useEffect(() => {
    setPage(0);
  }, [perPage]);

  const go = (dir) => {
    setPage((p) => (p + dir + totalPages) % totalPages);
  };

  const visible = items.slice(page * perPage, page * perPage + perPage);

  return (
    <div className="slider">
      <button
        className="slider-arrow left"
        onClick={() => go(-1)}
        aria-label="Previous projects"
      >
        ‹
      </button>

      <div className="slider-track">
        {visible.map((project, i) => (
          <Reveal key={project.title} delay={i * 120}>
            <div className="project-card">
              <div className="project-thumb">
                <img src={project.image} alt={project.title} />
              </div>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <button
        className="slider-arrow right"
        onClick={() => go(1)}
        aria-label="Next projects"
      >
        ›
      </button>

      <div className="slider-dots">
        {Array.from({ length: totalPages }).map((_, i) => (
          <button
            key={i}
            className={`dot ${i === page ? "active" : ""}`}
            onClick={() => setPage(i)}
            aria-label={`Go to page ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const body = `Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`;
    const mailto = `mailto:nimrachaudhary273@gmail.com?subject=${encodeURIComponent(
      form.subject || "Portfolio contact"
    )}&body=${encodeURIComponent(body)}`;
    window.location.href = mailto;
    setSent(true);
  };

  return (
    <form className="contact-form" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Your name"
        value={form.name}
        onChange={update("name")}
        required
      />
      <input
        type="email"
        placeholder="Your email"
        value={form.email}
        onChange={update("email")}
        required
      />
      <select value={form.subject} onChange={update("subject")} required>
        <option value="" disabled>
          What's this about?
        </option>
        <option value="Frontend role">Frontend role</option>
        <option value="Freelance project">Freelance project</option>
        <option value="Just saying hi">Just saying hi</option>
      </select>
      <textarea
        placeholder="Your message"
        rows={4}
        value={form.message}
        onChange={update("message")}
        required
      />
      <button type="submit" className="btn btn-primary">
        Send message
      </button>
      {sent && <p className="form-note">Opening your email app…</p>}
    </form>
  );
}

function Reveal({ children, className = "", delay = 0, direction = "up" }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(el);
        }
      },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const directionClass = direction === "left" ? "reveal-left" : direction === "right" ? "reveal-right" : "";

  return (
    <div
      ref={ref}
      className={`reveal ${directionClass} ${visible ? "visible" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

const skillGroups = [
  {
    label: "Frontend",
    tags: ["HTML5", "CSS3", "JavaScript", "Responsive Web Design"],
  },
  {
    label: "Frameworks & styling",
    tags: ["Bootstrap", "Tailwind CSS"],
  },
  {
    label: "UI implementation",
    tags: ["Figma", "Adobe XD", "Pixel-focused implementation"],
  },
  {
    label: "CMS",
    tags: ["WordPress", "Theme customization"],
  },
  {
    label: "Practice",
    tags: ["Git", "Version control", "Debugging", "Clean code"],
  },
];

const allSkillTags = skillGroups.flatMap((group) => group.tags);

const experience = [
  {
    date: "2025 — Present",
    role: "Frontend Developer",
    org: "QM Logics",
    points: [
      "Develop and maintain responsive, user-friendly web interfaces using HTML, CSS, and JavaScript.",
      "Translate UI/UX designs from Figma and Adobe XD into high-quality, pixel-focused implementations.",
      "Debug and resolve UI issues to improve functionality, consistency, and user experience.",
    ],
  },
  {
    date: "2023 — 2025",
    role: "Teacher",
    org: "Foundation Public School",
    points: [
      "Planned and delivered curriculum-aligned lessons for students with diverse learning needs.",
      "Maintained a positive, disciplined, and inclusive classroom environment.",
      "Used modern teaching methods and teaching aids to support student understanding.",
    ],
  },
];

const education = [
  {
    date: "2019 — 2022",
    title: "Intermediate",
    org: "Government Graduate College Women",
  },
  {
    date: "2024 — 2025",
    title: "Web Development and Designing",
    org: "Tech Hub Institute, Bahawalpur",
  },
  {
    date: "2025",
    title: "Advanced Web Development",
    org: "Vocational Training Institute, Bahawalpur",
  },
];

const navLinks = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#projects", label: "Projects" },
  { href: "#experience", label: "Experience" },
  { href: "#education", label: "Education" },
  { href: "#contact", label: "Contact" },
];

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div>
      <nav className="topbar">
        <span className="mark">
          <span>{"</>"}</span> Nimra
        </span>
        <div className="links">
          {navLinks.map((link) => (
            <a key={link.href} href={link.href}>
              {link.label}
            </a>
          ))}
        </div>
        <button
          className={`hamburger ${menuOpen ? "open" : ""}`}
          onClick={() => setMenuOpen((o) => !o)}
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </nav>

      <div
        className={`mobile-menu-backdrop ${menuOpen ? "open" : ""}`}
        onClick={closeMenu}
      />
      <div className={`mobile-menu ${menuOpen ? "open" : ""}`}>
        {navLinks.map((link, i) => (
          <a
            key={link.href}
            href={link.href}
            onClick={closeMenu}
            style={{ transitionDelay: menuOpen ? `${i * 60 + 80}ms` : "0ms" }}
          >
            {link.label}
          </a>
        ))}
      </div>

      <div className="page">
        <section className="hero" id="home" style={{ borderTop: "none" }}>
          <Reveal className="hero-text">
            <div className="role">
              Hi, I'm <span className="accent">Nimra!</span>
            </div>
            <h1>Frontend Developer</h1>
            <p className="lede">
              I turn Figma and Adobe XD designs into responsive,
              production-ready interfaces — then debug them until every
              state, breakpoint, and browser agrees.
            </p>
            <div className="hero-actions">
              <a className="btn btn-primary" href="#experience">
                My experience
              </a>
              <a className="btn btn-ghost" href="#contact">
                Get in touch
              </a>
            </div>
            <div className="hero-meta">
              <span>Bahawalpur, Pakistan</span>
              <span>nimrachaudhary273@gmail.com</span>
              <span>+92 313 6964787</span>
            </div>
          </Reveal>
          <Reveal className="hero-portrait" delay={150}>
            <img src={photo} alt="Nimra Chaudhary" />
            <div className="ring" />
          </Reveal>
        </section>
      </div>

      <div className="about page" id="about">
        <Reveal className="about-portrait">
          <img src={photo} alt="Nimra Chaudhary" />
        </Reveal>
        <Reveal className="about-copy" delay={150}>
          <h2>About me</h2>
          <p>
            Frontend Developer with professional experience building
            responsive, user-friendly web interfaces using HTML, CSS, and
            JavaScript. I'm experienced in translating Figma and Adobe XD
            designs into high-quality, pixel-focused implementations, and
            comfortable working with WordPress, Bootstrap, and Tailwind CSS
            alongside designers, backend developers, and product teams.
          </p>

          <div className="skills-marquee">
            <div className="skills-track">
              {[...allSkillTags, ...allSkillTags].map((tag, i) => (
                <span className="skill-tag" key={`${tag}-${i}`}>
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <a className="btn btn-primary" href="#experience">
            View my experience
          </a>
        </Reveal>
      </div>

      <div className="page">
        <section id="projects" style={{ borderTop: "none" }}>
          <Reveal className="section-head">
            <h2>Projects</h2>
            <p>Frontend and full-site work delivered for clients across industries.</p>
          </Reveal>
          <Reveal>
            <ProjectSlider items={projects} />
          </Reveal>
        </section>

        <section id="experience">
          <Reveal className="section-head">
            <h2>Experience</h2>
            <p>From the classroom to the codebase.</p>
          </Reveal>
          <div className="timeline">
            {experience.map((job, i) => (
              <Reveal
                key={job.role}
                delay={i * 100}
                direction={i % 2 === 0 ? "left" : "right"}
              >
                <div className="timeline-entry">
                  <div className="timeline-date">{job.date}</div>
                  <h3>{job.role}</h3>
                  <div className="org">{job.org}</div>
                  <ul>
                    {job.points.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <section id="education">
          <Reveal className="section-head">
            <h2>Education</h2>
            <p>Formal study alongside hands-on web development training.</p>
          </Reveal>
          <div className="edu-list">
            {education.map((entry, i) => (
              <Reveal key={entry.title} delay={i * 120}>
                <div className="edu-entry">
                  <div className="edu-date">{entry.date}</div>
                  <h3>{entry.title}</h3>
                  <div className="org">{entry.org}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <Reveal>
          <footer className="contact" id="contact">
            <div className="footer-grid">
              <div className="footer-col">
                <h3>Contact</h3>
                <div className="footer-contact-item">
                  <span className="footer-label">Email</span>
                  <a href="mailto:nimrachaudhary273@gmail.com">
                    nimrachaudhary273@gmail.com
                  </a>
                </div>
                <div className="footer-contact-item">
                  <span className="footer-label">Phone</span>
                  <a href="tel:+923136964787">+92 313 6964787</a>
                </div>
                <div className="footer-contact-item">
                  <span className="footer-label">Location</span>
                  <span>Bahawalpur, Pakistan</span>
                </div>
                <p className="foot-note">
                  English — Intermediate · Urdu — Fluent · Punjabi — Fluent
                </p>
              </div>

              <div className="footer-col">
                <h3>Quick links</h3>
                <a href="#home">Home</a>
                <a href="#about">About</a>
                <a href="#projects">Projects</a>
                <a href="#experience">Experience</a>
                <a href="#education">Education</a>
              </div>

              <div className="footer-col footer-form-col">
                <h3>Send a message</h3>
                <p className="lede">Open to frontend roles and freelance work.</p>
                <ContactForm />
              </div>
            </div>
          </footer>
        </Reveal>
      </div>
    </div>
  );
}
